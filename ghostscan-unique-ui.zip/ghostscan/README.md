# 👻 GhostScan

**GhostScan** es un escáner TCP pequeño, rápido y educativo para practicar reconocimiento de red en laboratorios propios o con autorización expresa.

> [!IMPORTANT]
> GhostScan incorpora una restricción de seguridad: solo acepta direcciones loopback, privadas o link-local. No está diseñado para escanear sistemas públicos. Úsalo únicamente en equipos y redes que controles o para los que tengas permiso explícito.

## Identidad visual

GhostScan usa una estética de terminal propia: logotipo ASCII, paleta cian/azul, paneles de estado y un resumen de escaneo estilo *field console*. No necesita librerías de interfaz ni dependencias de terceros. Puedes desactivar los colores con `--no-color`.

## Características

- Escaneo TCP mediante conexiones `connect`.
- Resolución de hostname a IP y validación de destino de laboratorio.
- Puertos individuales y rangos (`22,80,443,8000-8010`).
- Concurrencia configurable.
- Identificación básica del nombre de servicio según el puerto.
- Exportación de resultados a JSON.
- Sin dependencias externas: usa la biblioteca estándar de Python.

## Requisitos

- Python 3.10 o superior.
- Linux, macOS o Windows.

## Instalación

```bash
git clone https://github.com/TU-USUARIO/ghostscan.git
cd ghostscan
python -m ghostscan --help
```

No requiere `pip install`.

## Uso

Escanear puertos comunes en tu propia máquina:

```bash
python -m ghostscan 127.0.0.1 --ports 22,80,443,8000-8010
```

Escanear un equipo privado de tu laboratorio:

```bash
python -m ghostscan 192.168.1.20 --ports 1-1024 --timeout 0.7
```

Desactivar colores (por ejemplo, para logs o terminales sin ANSI):

```bash
python -m ghostscan 127.0.0.1 --ports 22,80,443 --no-color
```

Guardar un informe:

```bash
python -m ghostscan 127.0.0.1 --ports 1-1024 --json informe.json
```

Limitar la concurrencia:

```bash
python -m ghostscan 127.0.0.1 --ports 1-1000 --workers 32
```

## Ejemplo de salida

```text
PUERTO    ESTADO        SERVICIO
--------------------------------------
22        open          ssh
8000      open          unknown

[+] Finalizado. 2 puertos abiertos de 14 comprobados.
```

## Ejecutar tests

```bash
python -m unittest discover -s tests -v
```

## Estructura

```text
ghostscan/
├── ghostscan/
│   ├── __init__.py
│   ├── __main__.py
│   ├── cli.py
│   └── scanner.py
├── tests/
│   └── test_scanner.py
├── .gitignore
├── LICENSE
└── README.md
```

## Limitaciones

- Es un escáner TCP de conexión, no un escáner SYN.
- Un puerto marcado como `closed` o `filtered` puede depender del firewall y de la red.
- El nombre del servicio se infiere del número de puerto; no confirma qué software está escuchando.
- No realiza explotación, fuerza bruta ni pruebas intrusivas.

## Roadmap

- [ ] Detección opcional de banners con límites de tiempo.
- [ ] Informes HTML.
- [ ] Perfiles de puertos habituales.
- [ ] Interfaz TUI.
- [ ] Comparación entre escaneos.

## Licencia

MIT. Consulta el archivo `LICENSE`.
