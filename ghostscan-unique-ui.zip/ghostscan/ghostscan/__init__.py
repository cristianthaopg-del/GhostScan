"""GhostScan: a small, lab-focused TCP reconnaissance tool."""
__version__ = "1.0.0"
