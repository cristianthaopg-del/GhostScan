from __future__ import annotations

import argparse
import json
import socket
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from . import __version__
from .scanner import parse_ports, result_to_dict, scan_ports, validate_lab_target

# GhostScan visual identity: "signal / radar" terminal aesthetic.
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[96m"
BLUE = "\033[94m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
WHITE = "\033[97m"


def paint(text: str, color: str, enabled: bool = True) -> str:
    return f"{color}{text}{RESET}" if enabled else text


def supports_color() -> bool:
    return sys.stdout.isatty() and "NO_COLOR" not in __import__("os").environ


def banner(color: bool = True) -> None:
    logo = [
        "   ▄████  ▒█████   ▄████ ▒███████▒  ██████  ▄████▄   ▄▄▄       ███▄    █ ",
        "  ██▒ ▀█▒▒██▒  ██▒ ██▒ ▀█▒▒ ▒ ▒ ▄▀░▒██    ▒ ▒██▀ ▀█  ▒████▄     ██ ▀█   █ ",
        " ▒██░▄▄▄░▒██░  ██▒▒██░▄▄▄░░ ▒ ▄▀▒░ ░ ▓██▄   ▒▓█    ▄ ▒██  ▀█▄  ▓██  ▀█ ██▒",
        " ░▓█  ██▓▒██   ██░░▓█  ██▓  ▄▀▒   ░  ▒   ██▒▒▓▓▄ ▄██▒░██▄▄▄▄██ ▓██▒  ▐▌██▒",
        " ░▒▓███▀▒░ ████▓▒░░▒▓███▀▒▒███████▒▒██████▒▒▒ ▓███▀ ░ ▓█   ▓██▒▒██░   ▓██░",
        "  ░▒   ▒ ░ ▒░▒░▒░  ░▒   ▒ ░▒▒ ▓░▒░▒▒ ▒▓▒ ▒ ░░ ░▒ ▒  ░ ▒▒   ▓▒█░░ ▒░   ▒ ▒ ",
        "   ░   ░   ░ ▒ ▒░   ░   ░ ░░▒ ▒ ░ ▒░ ░▒  ░ ░  ░  ▒     ▒   ▒▒ ░░ ░░   ░ ▒░",
        " ░ ░   ░ ░ ░ ░ ▒  ░ ░   ░ ░ ░ ░ ░ ░░  ░  ░  ░          ░   ▒      ░   ░ ░ ",
        "       ░     ░ ░        ░   ░ ░          ░  ░ ░            ░  ░         ░ ",
        "                         ░                ░",
    ]
    for line in logo:
        print(paint(line, CYAN + BOLD, color))
    print(paint("  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", BLUE, color))
    print(paint("  FIELD NOTES  /  NETWORK RECON  /  LOCAL LAB EDITION", DIM + WHITE, color))
    print()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ghostscan",
        description="Escáner TCP educativo para laboratorios locales autorizados.",
        epilog="Ejemplo: ghostscan 127.0.0.1 --ports 22,80,443,8000-8010",
    )
    parser.add_argument("target", help="IP o hostname que resuelva a una IP privada/de laboratorio")
    parser.add_argument("--ports", default="1-1024", help="Puertos o rangos separados por comas (por defecto: 1-1024)")
    parser.add_argument("--timeout", type=float, default=0.5, help="Timeout por puerto en segundos")
    parser.add_argument("--workers", type=int, default=64, help="Conexiones concurrentes (1-128)")
    parser.add_argument("--json", dest="json_path", help="Guardar resultados en un archivo JSON")
    parser.add_argument("--no-color", action="store_true", help="Desactivar colores ANSI")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return parser


def section(label: str, color: bool) -> None:
    print(paint(f"  ◈ {label}", CYAN + BOLD, color))


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    color = supports_color() and not args.no_color
    banner(color)

    try:
        if not 0.05 <= args.timeout <= 5:
            raise ValueError("El timeout debe estar entre 0.05 y 5 segundos.")
        if not 1 <= args.workers <= 128:
            raise ValueError("Los workers deben estar entre 1 y 128.")
        ports = parse_ports(args.ports)
        host = validate_lab_target(args.target)
    except ValueError as exc:
        print(paint(f"  [!] {exc}", RED, color), file=sys.stderr)
        return 2

    try:
        resolved_name = socket.gethostbyaddr(host)[0]
    except (socket.herror, socket.gaierror):
        resolved_name = host

    section("TARGET PROFILE", color)
    print(f"  {paint('HOST', DIM, color):<18} {resolved_name}")
    print(f"  {paint('ADDRESS', DIM, color):<18} {host}")
    print(f"  {paint('PORT RANGE', DIM, color):<18} {len(ports)} probes")
    print(f"  {paint('THREADS', DIM, color):<18} {args.workers}")
    print(f"  {paint('TIMEOUT', DIM, color):<18} {args.timeout:.2f}s")
    print()

    section("LIVE SCAN", color)
    started = time.perf_counter()
    results = scan_ports(host, ports, args.timeout, args.workers)
    elapsed = time.perf_counter() - started
    opened = [item for item in results if item.state == "open"]

    width = 58
    print(paint("  ┌" + "─" * width + "┐", BLUE, color))
    print(paint("  │", BLUE, color) + f" {'PORT':<9} {'STATE':<12} {'SERVICE':<28}" + paint("│", BLUE, color))
    print(paint("  ├" + "─" * width + "┤", BLUE, color))
    if opened:
        for item in opened:
            state = paint("OPEN", GREEN + BOLD, color)
            print(paint("  │", BLUE, color) + f" {item.port:<9} {state:<21} {item.service:<28}" + paint("│", BLUE, color))
    else:
        print(paint("  │", BLUE, color) + f" {paint('No open TCP ports found.', DIM, color):<56}" + paint("│", BLUE, color))
    print(paint("  └" + "─" * width + "┘", BLUE, color))

    rate = len(results) / elapsed if elapsed > 0 else 0
    print()
    section("SCAN SUMMARY", color)
    print(f"  {paint('OPEN', GREEN + BOLD, color):<18} {len(opened)}")
    print(f"  {paint('CHECKED', DIM, color):<18} {len(results)}")
    print(f"  {paint('DURATION', DIM, color):<18} {elapsed:.2f}s")
    print(f"  {paint('THROUGHPUT', DIM, color):<18} {rate:.1f} ports/s")

    if args.json_path:
        report = {
            "tool": "GhostScan",
            "version": __version__,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "target": host,
            "ports_checked": len(results),
            "open_ports": [result_to_dict(item) for item in opened],
            "duration_seconds": round(elapsed, 3),
        }
        path = Path(args.json_path)
        path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        print()
        print(paint(f"  ↳ Report archived: {path}", GREEN, color))

    print()
    print(paint("  GHOSTSCAN  /  KEEP YOUR SIGNAL CLEAN.", DIM + CYAN, color))
    print(paint("  Use only on systems you own or are authorized to assess.", DIM, color))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
