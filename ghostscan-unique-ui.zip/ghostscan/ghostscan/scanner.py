from __future__ import annotations

import ipaddress
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from typing import Iterable


@dataclass
class ScanResult:
    port: int
    state: str
    service: str


def validate_lab_target(target: str) -> str:
    """Resolve a target and allow only loopback/private/link-local lab addresses."""
    try:
        address = ipaddress.ip_address(target)
    except ValueError:
        try:
            infos = socket.getaddrinfo(target, None, type=socket.SOCK_STREAM)
        except socket.gaierror as exc:
            raise ValueError(f"No se pudo resolver el destino: {exc}") from exc
        addresses = sorted({info[4][0] for info in infos})
        if not addresses:
            raise ValueError("El destino no resolvió a ninguna dirección IP.")
        parsed = [ipaddress.ip_address(item) for item in addresses]
        if not all(_is_lab_address(item) for item in parsed):
            raise ValueError(
                "GhostScan solo permite destinos loopback, privados o link-local. "
                "Usa un laboratorio propio."
            )
        return addresses[0]

    if not _is_lab_address(address):
        raise ValueError(
            "GhostScan solo permite destinos loopback, privados o link-local. "
            "Usa un laboratorio propio."
        )
    return str(address)


def _is_lab_address(address: ipaddress._BaseAddress) -> bool:
    return (
        address.is_loopback
        or address.is_private
        or address.is_link_local
    )


def parse_ports(value: str) -> list[int]:
    """Parse comma-separated ports and ranges, e.g. 22,80,8000-8010."""
    ports: set[int] = set()
    for chunk in value.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            parts = chunk.split("-", maxsplit=1)
            if len(parts) != 2:
                raise ValueError(f"Rango inválido: {chunk}")
            start, end = map(int, parts)
            if start > end:
                raise ValueError(f"Rango invertido: {chunk}")
            ports.update(range(start, end + 1))
        else:
            ports.add(int(chunk))

    if not ports:
        raise ValueError("Debes indicar al menos un puerto.")
    if any(port < 1 or port > 65535 for port in ports):
        raise ValueError("Los puertos deben estar entre 1 y 65535.")
    if len(ports) > 2048:
        raise ValueError("Máximo 2048 puertos por ejecución.")
    return sorted(ports)


def scan_port(host: str, port: int, timeout: float = 0.5) -> ScanResult:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            code = sock.connect_ex((host, port))
        state = "open" if code == 0 else "closed"
    except OSError:
        state = "filtered"
    try:
        service = socket.getservbyport(port, "tcp")
    except OSError:
        service = "unknown"
    return ScanResult(port=port, state=state, service=service)


def scan_ports(
    host: str,
    ports: Iterable[int],
    timeout: float = 0.5,
    workers: int = 64,
) -> list[ScanResult]:
    results: list[ScanResult] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(scan_port, host, port, timeout): port for port in ports
        }
        for future in as_completed(futures):
            results.append(future.result())
    return sorted(results, key=lambda result: result.port)


def result_to_dict(result: ScanResult) -> dict:
    return asdict(result)
