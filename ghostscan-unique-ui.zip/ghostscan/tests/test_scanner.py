import unittest

from ghostscan.scanner import parse_ports, validate_lab_target


class ScannerTests(unittest.TestCase):
    def test_parse_ports_and_ranges(self):
        self.assertEqual(parse_ports("80,443,8000-8002"), [80, 443, 8000, 8001, 8002])

    def test_reject_invalid_port(self):
        with self.assertRaises(ValueError):
            parse_ports("0,80")

    def test_accept_loopback(self):
        self.assertEqual(validate_lab_target("127.0.0.1"), "127.0.0.1")

    def test_reject_public_ip(self):
        with self.assertRaises(ValueError):
            validate_lab_target("8.8.8.8")


if __name__ == "__main__":
    unittest.main()
